#!/bin/sh
/usr/java/jre1.8.0_171/bin/java -jar LM50Client.jar 8